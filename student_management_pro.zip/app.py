
from flask import Flask, render_template
import mysql.connector

app = Flask(__name__)

db = mysql.connector.connect(
    host="localhost",
    user="root",
    password="root",
    database="student_management"
)

@app.route('/')
def dashboard():
    cur=db.cursor(dictionary=True)
    cur.execute("SELECT * FROM students")
    students=cur.fetchall()
    return render_template('dashboard.html',students=students,total=len(students))

@app.route('/students')
def students():
    cur=db.cursor(dictionary=True)
    cur.execute("SELECT * FROM students")
    return render_template('students.html',students=cur.fetchall())

if __name__=='__main__':
    app.run(debug=True)
